#include <stdio.h>
int main () {

int a=5,b=10,mul;
mul=a*b;

printf("The Multiplication of %d and %d in %d", a,b,mul);



return 0;
}
