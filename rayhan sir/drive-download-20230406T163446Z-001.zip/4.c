#include<stdio.h>
#include<conio.h>
void main()
{
    int a;
    a=5<=8 && 6!=5;
    printf("%d",a);
getch ();

}
