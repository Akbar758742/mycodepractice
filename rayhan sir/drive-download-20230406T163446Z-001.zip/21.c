#include<stdio.h>
#include<conio.h>
#include<math.h>
int main(){

    char Str1[10]="WORD";
    char Str2[10]="PROCESSING";

    printf("%s ",Str1);
    printf(" %s\n",Str2);
    printf("%s\n",Str1);
    printf("%s\n",Str2);
    printf("%.1s.%.1s.",Str1,Str2);
return 0;
}
