#include <stdio.h>
int main() {

printf("I see, I remember");

return 0;
}
