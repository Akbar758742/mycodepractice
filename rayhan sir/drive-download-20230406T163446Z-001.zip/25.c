#include <stdio.h>
int main() {

int a= 100;
float amount,b= 6.10;

amount=a+b;
printf("%d\n",a);
printf("%.2f",amount);

return 0;
}
