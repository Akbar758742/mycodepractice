#include<stdio.h>
main(){
    printf("integer values\n\n");
    printf("%d %d %d",32767,32767+1,32767+10);
    printf("\n");
    printf("long integer values\n\n");
    printf("%ld %ld %ld",32767L,32767L+1L,32767L+10L);

}
